﻿namespace ContactManagementWebApplication.Models
{
    public class ContactInfo
    {
        public  int ContactId { get; set; }   
        public  string FirstName { get; set; }
        public  string LastName { get; set; }
        public  string CompanyName { get; set; }
        public  string EmailId { get; set; }
        public  double MobileNo { get; set; }
        public  string Designation { get; set; }

    }
}
