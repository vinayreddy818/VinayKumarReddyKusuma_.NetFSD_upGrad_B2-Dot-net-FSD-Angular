﻿using ContactManagementWebApplication.DataAccess;
using ContactManagementWebApplication.Models;
using Microsoft.AspNetCore.Mvc;

namespace ContactManagementWebApplication.Controllers
{
    public class ContactInfoController : Controller
    {

        private readonly IContactService<ContactInfo> _ContactService;
        public ContactInfoController(IContactService<ContactInfo> ContactService) { 
            this._ContactService = ContactService;
        }
        [Route("/")]  //start-up route
        [Route("ShowContacts", Name = "ShowContacts")]        
        public IActionResult ShowContacts()
        {
            var GetAllContacts = _ContactService.ShowContacts();
            return View(GetAllContacts);
        }

        [Route("GetById/{id?}", Name = "GetById")]
        public IActionResult GetContactInfoById(int? id)
        {
            var Result = _ContactService.GetContactById(id);
            if (Result != null) {
                return View(Result);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpGet]
        [Route("AddContact", Name = "AddContact")]
        public IActionResult AddContactInfo()
        {
            return View();
        }

        [HttpPost]
        [Route("SaveContact", Name = "SaveContact")]
        public IActionResult AddContactInfo(ContactInfo contacts)
        {
            var isSaved = _ContactService.AddContact(contacts);
            if (isSaved)
            {
                return RedirectToRoute("ShowContacts");
            }
            else
            {
                return BadRequest();
            }
        }
    }
}
