﻿namespace ContactManagementWebApplication.DataAccess
{
    public interface IContactService<TEntity>
    {
        public  List<TEntity> ShowContacts();
        public  TEntity GetContactById(int? n);
        public  bool AddContact(TEntity entity);

    }
}
