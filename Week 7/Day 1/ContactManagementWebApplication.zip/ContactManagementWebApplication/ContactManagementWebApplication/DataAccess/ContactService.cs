﻿using ContactManagementWebApplication.Models;

namespace ContactManagementWebApplication.DataAccess
{
    public class ContactService: IContactService<ContactInfo>
    {
        public static List<ContactInfo> contacts = new List<ContactInfo>
        {
        new ContactInfo{ ContactId =101, FirstName = "Vinay", LastName ="Kusuma" , CompanyName ="upgrad",EmailId ="vinay@upgrad.com", MobileNo = 8738282832, Designation =".NET Developer"},
        new ContactInfo{ ContactId =102, FirstName = "rahul", LastName ="k" , CompanyName ="Cognizant",EmailId ="rahul@cognizant.com", MobileNo = 8738282832, Designation ="Full stack .NET Developer"},
        new ContactInfo{ ContactId =103, FirstName = "raghu", LastName ="d" , CompanyName ="TCS",EmailId ="raghu@tcs.com", MobileNo = 8738282832, Designation =".NET Developer"}
        };
        public List<ContactInfo> ShowContacts()
        {
            return contacts;
        }
        public ContactInfo GetContactById(int? n)
        {
            var ContactById = contacts.FirstOrDefault(c => c.ContactId.Equals(n));
            return ContactById;
        }
        public bool AddContact(ContactInfo entity)
        {
            contacts.Add(entity);
            return true;
        }
    }
}
